﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvcdemo3.Models
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
    }
}